AFRICA CAISSE – PROJET ANDROID NATIF (SOURCE)

Ce dossier est un projet Android Studio natif qui embarque l'application AFRICA CAISSE dans une WebView locale. L'application peut fonctionner hors connexion et conserve les données localement sur l'appareil.

POUR GENERER L'APK :
1. Installer Android Studio (version récente) sur un ordinateur.
2. Décompresser ce dossier.
3. Dans Android Studio : File > Open, sélectionner le dossier AFRICA_CAISSE_ANDROID_NATIVE.
4. Attendre la synchronisation Gradle et installer le SDK Android API 35 si Android Studio le demande.
5. Choisir Build > Build Bundle(s) / APK(s) > Build APK(s).
6. L'APK debug sera créé dans app/build/outputs/apk/debug/app-debug.apk.
7. Transférer l'APK sur le téléphone Android et l'installer. Autoriser l'installation depuis cette source si Android le demande.

IMPORTANT :
- Ce livrable est le projet source Android Studio, pas un APK déjà compilé.
- L'environnement de création utilisé ne contient pas Android SDK ni Gradle ; il ne peut donc pas produire ni tester le binaire APK ici.
- Les données sont locales à un appareil. Il n'y a pas encore de synchronisation serveur multi-caisses.
- Le personnel et rôles sont des libellés opérationnels, pas une authentification sécurisée.
- Effectuer des essais complets et des sauvegardes avant usage commercial.
